
<?php $__env->startSection('title', 'Income List'); ?>

<?php $__env->startSection('content'); ?>



<div class="container">
    <h3>🔔 Membership Renewal Notice (Expiring in 30–60 Days)</h3>

    <?php if($expiringSoon->isEmpty()): ?>
        <div class="alert alert-success">No upcoming renewals found.</div>
    <?php else: ?>
        <table class="table table-bordered table-striped">
            <thead class="thead-dark">
                <tr>
                    <th>SL No</th>
                    <th>Member ID</th>
                    <th>Name</th>
                    <th>Phone</th>
                    <th>Plan</th>
                    <th>Status</th>
                    <th>Join Date</th>
                    <th>Expiry Date</th>
                    <th>Renew</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1; ?>
                <?php $__currentLoopData = $expiringSoon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($member->member_id); ?></td>
                    <td><?php echo e($member->name); ?></td>
                    <td><?php echo e($member->phone); ?></td>
                    <td><?php echo e($member->select_plan_name); ?></td>
                    <td>
                        <?php if($member->status == 1): ?>
                            <span class="badge badge-success">Active</span>
                        <?php elseif($member->status == 2): ?>
                            <span class="badge badge-warning">Pending</span>
                        <?php else: ?>
                            <span class="badge badge-danger">Expired</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e(\Carbon\Carbon::parse($member->join_date)->format('d-m-Y')); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($member->expiry_date)->format('d-m-Y')); ?></td>
                    <td>
                        <a href="<?php echo e(url('/renew-member/' . $member->member_id)); ?>" class="btn btn-sm btn-primary">Renew</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\goglyMart\MLMLara\backend\resources\views/admin/renewals/notify.blade.php ENDPATH**/ ?>