
<?php $__env->startSection('title', 'Package Master'); ?>

<?php $__env->startSection('content'); ?>


<!-- Main content -->
<section class="content">
    <div class="row">
        <!-- left column -->
        <div class="col-md-4">
            <!-- general form elements -->
            <div class="box box-primary">

                <?php if(session('success')): ?>
                <div class="flash-message flash-success">
                    <?php echo e(session('success')); ?>

                    <button class="close-btn" onclick="this.parentElement.style.display='none';">&times;</button>
                </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                <div class="flash-message flash-error">
                    <ul style="margin-bottom: 0;">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <button class="close-btn" onclick="this.parentElement.style.display='none';">&times;</button>
                </div>
                <?php endif; ?>

                <form role="form" method="POST" action="<?php echo e(route('packageMaster.store')); ?>"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="box-body">
                        <p class="from-top-header">Package Master</p>
                        <div class="row">
                            <div class="form-group col-sm-12">
                                <label>Package Name<sup>*</sup></label>
                                <input type="text" class="form-control" name="package_name"
                                    value="<?php echo e(old('package_name')); ?>" required>
                            </div>

                            <div class="form-group col-sm-12">
                                <label>Package Amount<sup>*</sup></label>
                                <input min="1" type="number" class="form-control packageAmount" name="package_amount"
                                    value="<?php echo e(old('package_amount')); ?>" required>
                            </div>

                            <div class="form-group col-sm-12">
                                <label>Package %<sup>*</sup></label>
                                <input min="1" type="number" class="form-control packagePer" name="package_payout_per"
                                    value="<?php echo e(old('package_payout_per')); ?>" required>
                            </div>

                            <div class="form-group col-sm-12">
                                <label>Total Amount<sup>*</sup></label>
                                <input min="1" readonly type="number" class="form-control totalAmount"
                                    name="package_total_amount" value="<?php echo e(old('package_total_amount')); ?>" required>
                            </div>

                            <div class="form-group col-sm-12">
                                <label>Time Duration in Min <sup>1 Day = 24 x 60 = 1440 min </sup> <sup>*</sup></label>
                                <input min="1" type="number" class="form-control" name="package_time_duration"
                                    value="<?php echo e(old('package_time_duration')); ?>" required>
                            </div>
                        </div>

                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </div>
                </form>



                <script>
                    document.addEventListener("input", () => {
                        const packageAmount = parseFloat(document.querySelector(".packageAmount")?.value) || 0;
                        const packagePer = parseFloat(document.querySelector(".packagePer")?.value) || 0;
                        //   document.querySelector(".totalAmount").value = (packageAmount * packagePer / 100).toFixed(2);
                        document.querySelector(".totalAmount").value = Math.round(packageAmount * packagePer / 100 + packageAmount  || '');
                    });
                </script>


            </div><!-- /.box -->
        </div>
        <div class="col-md-8">
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Package View</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                    <table id="fileTable1" class="display responsive nowrap" style="width:100%">
                        <thead>
                            <tr>
                                <th>SL No</th>
                                <th>Package Name</th>
                                <th>Package Amount</th>
                                <th>Package %</th>
                                <th>Total Amount</th>
                                <th>Time Duration</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e($package->package_name); ?></td>
                                <td><?php echo e($package->package_amount); ?></td>
                                <td><?php echo e($package->package_payout_per); ?> %</td>
                                <td><?php echo e($package->package_amount); ?> + <?php echo e($package->package_payout_per); ?> % = <?php echo e($package->package_total_amount); ?></td>
                                <td><?php echo e($package->package_time_duration); ?> min</td>
                                <td>

                        <form action="<?php echo e(route('generic.delete', ['table' => 'package_master', 'id' => $package->id])); ?>" method="POST" style="display:inline-block;" onsubmit="return confirm('Are you sure want to delete <?php echo e($package->package_name); ?>?')">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-danger">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </form>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>

                </div><!-- /.box-body -->
            </div>
        </div>

    </div>
</section><!-- /.content -->



</div><!-- /.content-wrapper -->




<?php $__env->stopSection(); ?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<script>
    <?php if(session('success')): ?>
        toastr.success("<?php echo e(session('success')); ?>");
    <?php endif; ?>

    <?php if($errors -> any()): ?>
        toastr.error("<?php echo e($errors->first()); ?>");
    <?php endif; ?>
</script>

<script>
    setTimeout(() => {
        document.querySelectorAll('.flash-message').forEach(el => {
            el.style.transition = "opacity 0.5s";
            el.style.opacity = 0;
            setTimeout(() => el.style.display = 'none', 500);
        });
    }, 4000);
</script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\goglyMart\logic-service\resources\views/admin/logicApp/packageMaster.blade.php ENDPATH**/ ?>