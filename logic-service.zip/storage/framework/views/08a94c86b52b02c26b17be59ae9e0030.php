
<?php $__env->startSection('title', 'Plan Master'); ?>

<?php $__env->startSection('content'); ?>


<!-- Main content -->
<section class="content">
    <div class="row">
        <!-- left column -->
        <div class="col-md-4">
            <!-- general form elements -->
            <div class="box box-primary">

                <?php if(session('success')): ?>
                <div class="flash-message flash-success">
                    <?php echo e(session('success')); ?>

                    <button class="close-btn" onclick="this.parentElement.style.display='none';">&times;</button>
                </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                <div class="flash-message flash-error">
                    <ul style="margin-bottom: 0;">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <button class="close-btn" onclick="this.parentElement.style.display='none';">&times;</button>
                </div>
                <?php endif; ?>

                <form role="form" method="POST" action="<?php echo e(url('/plan-master')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="box-body">
                        <p class="from-top-header">Plan Master</p>
                        <div class="row">
                            <!-- select Plan -->
                            <div class="form-group col-sm-12">
                                <label>Select Plan*</label>
                                <select class="form-control" name="select_plan_id" required>
                                    <option disabled selected>Select Plan</option>
                                    <?php $__currentLoopData = $planNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($plan->id); ?>"><?php echo e($plan->plan_names); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group col-sm-12">
                                <label>Plan Amount<sup>*</sup></label>
                                <input type="number" class="form-control" name="plan_amount"
                                    value="<?php echo e(old('plan_amount')); ?>" required>
                            </div>

                            <div class="form-group col-sm-12">
                                <label>Plan PayOut<sup>*</sup></label>
                                <input type="number" class="form-control" name="plan_payout"
                                    value="<?php echo e(old('plan_payout')); ?>" required>
                            </div>
                        </div>

                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </div>
                </form>




            </div><!-- /.box -->
        </div>
        <div class="col-md-8">
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Plan View</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                    <table id="fileTable1" class="display responsive nowrap" style="width:100%">
                        <thead>
                            <tr>
                                <th>SL No</th>
                                <th>Plan Name</th>
                                <th>Plan Amount</th>
                                <th>Payout</th>
                                <th>Level</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 1; ?>
                            <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($plan->select_plan); ?></td>
                                <td><?php echo e($plan->plan_amount); ?></td>
                                <td><?php echo e($plan->plan_payout); ?></td>
                                <td><?php echo e($plan->plan_level); ?></td>
                                <td>
                                    <a href="<?php echo e(route('plan.delete', $plan->id)); ?>" class="btn btn-danger btn-sm"
                                        onclick="return confirm('Are you sure to delete this <?php echo e($plan->select_plan); ?> plan?')">
                                        Delete
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div><!-- /.box-body -->
            </div>
        </div>

    </div>
</section><!-- /.content -->



</div><!-- /.content-wrapper -->




<?php $__env->stopSection(); ?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<script>
    <?php if(session('success')): ?>
        toastr.success("<?php echo e(session('success')); ?>");
    <?php endif; ?>

    <?php if($errors -> any()): ?>
        toastr.error("<?php echo e($errors->first()); ?>");
    <?php endif; ?>
</script>

<script>
    setTimeout(() => {
        document.querySelectorAll('.flash-message').forEach(el => {
            el.style.transition = "opacity 0.5s";
            el.style.opacity = 0;
            setTimeout(() => el.style.display = 'none', 500);
        });
    }, 4000);
</script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\goglyMart\logic-service\resources\views/admin/plan_master.blade.php ENDPATH**/ ?>