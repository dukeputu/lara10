
<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>



     <!-- App Header -->
    <div class="appHeader">
        <div class="left">
            <a href="<?php echo e(route('dashboard.app')); ?>" class="headerButton ">
                <ion-icon name="chevron-back-outline"></ion-icon>
            </a>
        </div>
        <div class="pageTitle">
            Transactions
        </div>
        
    </div>
    <!-- * App Header -->


    <!-- App Capsule -->
    <div id="appCapsule">

        <!-- Transactions -->
        <div class="section mt-2">
        











<div class="transactions">
    <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $txn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php
            $isDebit = in_array($txn->type, ['Withdrawal', 'Package Buy']);
            $bgClass = match($txn->status) {
                'Done' => 'bg-success text-white',
                'Pending' => 'bg-warning text-dark',
                'Failed' => 'bg-danger text-white',
                default => 'bg-light text-dark'
            };

            $icon = match($txn->type) {
                'Withdrawal' => '💸',
                'Maturity' => '💰',
                'Package Buy' => '📦',
                'Add Balance' => '➕',
                default => '🔄'
            };

            $statusBadge = match($txn->status) {
                'Done' => 'badge-success',
                'Pending' => 'badge-warning',
                'Failed' => 'badge-danger',
                default => 'badge-secondary'
            };
        ?>

        <div class="card mb-3 <?php echo e($bgClass); ?> rounded shadow-sm">
            <div class="card-body d-flex justify-content-between align-items-center flex-wrap">
                
                <!-- Left: Type and Time -->
                <div class="text-start" style="min-width: 40%;">
                    <h6 class="mb-1"><?php echo e($icon); ?> <?php echo e($txn->type); ?></h6>
                    <div class="small">
                        <span class="badge <?php echo e($statusBadge); ?>"><?php echo e($txn->status); ?></span><br>
                        <strong>Req:</strong> <?php echo e(\Carbon\Carbon::parse($txn->requested_at)->format('d-m-Y h:i A')); ?><br>
                        <?php if($txn->done_at): ?>
                            <strong>Done:</strong> <?php echo e(\Carbon\Carbon::parse($txn->done_at)->format('d-m-Y h:i A')); ?><br>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Center: Wallet Info -->
                <div class="text-center small" style="min-width: 25%;">
                    <div><strong>Wallet</strong></div>
                    <div>Before: ₹<?php echo e(number_format($txn->wallet_before, 2)); ?></div>
                    <div>After: ₹<?php echo e(number_format($txn->wallet_after, 2)); ?></div>
                </div>

                <!-- Right: Amount -->
                <div class="text-end" style="min-width: 25%;">
                    <div class="h5 <?php echo e($isDebit ? 'text-white' : 'text-white'); ?>">
                        ₹<?php echo e(number_format($txn->amount, 2)); ?>

                        <small class="text-uppercase">(<?php echo e($isDebit ? 'Dr' : 'Cr'); ?>)</small>
                    </div>

                    <?php if($txn->type === 'Withdrawal' && $txn->screenshot && $txn->screenshot !== '0'): ?>
                        <div class="mt-1">
                            <img style="cursor: pointer;" src="<?php echo e(asset($txn->screenshot)); ?>" alt="Screenshot" width="40" height="40" class="rounded border"
                                 onclick="showScreenshot(this.src)" data-bs-toggle="modal" data-bs-target="#ModalBasic">
                        </div>
                    <?php endif; ?>
                </div>

            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="alert alert-info text-center">No transactions found.</div>
    <?php endif; ?>
</div>













        <!-- Modal Basic -->
        <div class="modal fade modalbox" id="ModalBasic" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Modal title</h5>
                        <a href="#" data-bs-dismiss="modal">Close</a>
                    </div>
                    <div class="modal-body">
                        <img style="max-width: 300px" id="modal-img" src="">
                    </div>
                </div>
            </div>
        </div>
        <!-- * Modal Basic -->

<script>
function showScreenshot(src) {
    document.getElementById('modal-img').src = src;
}
</script>


        </div>
        <!-- * Transactions -->






    </div>
    <!-- * App Capsule -->






<?php $__env->stopSection(); ?>

<?php echo $__env->make('userApp.layouts.userAppLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\goglyMart\logic-service\resources\views/userApp/userAppView/allTransactions.blade.php ENDPATH**/ ?>