

<!doctype html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover">
    <title><?php echo $__env->yieldContent('title', 'MLM App'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('userApp/assets/css/style.css')); ?>">


<style>
.appBottomMenu {
    display: none;
}
</style>

</head>

<body>

    <!-- loader -->
    <div id="loader">
        <img src="<?php echo e(url('userApp/assets/goldCoin.webp')); ?>" alt="icon" class="loading-icon">
    </div>
    <!-- * loader -->
<?php /**PATH D:\laragon\www\goglyMart\logic-service\resources\views/userApp/layouts/partials/head.blade.php ENDPATH**/ ?>