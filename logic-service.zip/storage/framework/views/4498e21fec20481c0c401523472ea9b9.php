
<?php $__env->startSection('title', 'Income List'); ?>

<?php $__env->startSection('content'); ?>


<!-- Main content -->
<section class="content">
    <div class="row">
   
        <div class="col-md-12">
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title"><?php echo e($plan->select_plan); ?> Plan Income View</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
             <table id="fileTable1" class="display responsive nowrap" style="width:100%">
                    <thead>
                        <tr>
                            <th>SL No</th>
                            <th>Down Member</th>
                            <th>Your Level</th>
                            <th>Amount</th>
                            <th>Plan Name</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($tx->downline_name); ?> MUM/<?php echo e($tx->member_id); ?></td>
                                <td><?php echo e($tx->level); ?></td>
                                <td>₹<?php echo e(number_format($tx->amount, 2)); ?></td>
                                <td><?php echo e($plan->select_plan); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3" style="text-align: right;"><strong>Total Income:</strong></td>
                            <td colspan="2"><strong>₹<?php echo e(number_format($totalIncome, 2)); ?></strong></td>
                        </tr>
                    </tfoot>
            </table>

                </div>
            </div>
        </div>

    </div>
</section>
</div>




<?php $__env->stopSection(); ?>





<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<script>
    <?php if(session('success')): ?>
        toastr.success("<?php echo e(session('success')); ?>");
    <?php endif; ?>

    <?php if($errors -> any()): ?>
        toastr.error("<?php echo e($errors->first()); ?>");
    <?php endif; ?>
</script>

<script>
    setTimeout(() => {
        document.querySelectorAll('.flash-message').forEach(el => {
            el.style.transition = "opacity 0.5s";
            el.style.opacity = 0;
            setTimeout(() => el.style.display = 'none', 500);
        });
    }, 4000);
</script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\goglyMart\MLMLara\backend\resources\views/admin/plans/view.blade.php ENDPATH**/ ?>