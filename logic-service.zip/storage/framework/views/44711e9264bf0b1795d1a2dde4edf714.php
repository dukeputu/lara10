  
    <!-- App Bottom Menu -->
    <div class="appBottomMenu">
        <a href="index.html.htm" class="item active">
            <div class="col">
                <ion-icon name="pie-chart-outline"></ion-icon>
                <strong>Overview</strong>
            </div>
        </a>
        <a href="app-pages.html.htm" class="item">
            <div class="col">
                <ion-icon name="document-text-outline"></ion-icon>
                <strong>Pages</strong>
            </div>
        </a>
        <a href="app-components.html.htm" class="item">
            <div class="col">
                <ion-icon name="apps-outline"></ion-icon>
                <strong>Components</strong>
            </div>
        </a>
        <a href="app-cards.html.htm" class="item">
            <div class="col">
                <ion-icon name="card-outline"></ion-icon>
                <strong>My Cards</strong>
            </div>
        </a>
        <a href="app-settings.html.htm" class="item">
            <div class="col">
                <ion-icon name="settings-outline"></ion-icon>
                <strong>Settings</strong>
            </div>
        </a>
    </div>
    <!-- * App Bottom Menu -->


  <!-- ========= JS Files =========  -->
    <!-- Bootstrap -->
    <script src="<?php echo e(asset('userApp/assets/js/lib/bootstrap.bundle.min.js')); ?>"></script>
    <!-- Ionicons -->
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    
   <script src="<?php echo e(asset('userApp/assets/js/ionicons.js')); ?>"></script>
   <script src="<?php echo e(asset('userApp/assets/js/plugins/splide/splide.min.js')); ?>"></script>
    <!-- Base Js File -->
    <script src="<?php echo e(asset('userApp/assets/js/base.js')); ?>"></script>
</body>

</html><?php /**PATH D:\laragon\www\goglyMart\MLMLara\backend\resources\views/userApp/layouts/partials/footer.blade.php ENDPATH**/ ?>