



<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>



<!-- App Header -->
<div class="appHeader">
    <div class="left">
        <a href="<?php echo e(route('dashboard.app')); ?>" class="headerButton ">
            <ion-icon name="chevron-back-outline"></ion-icon>
        </a>
    </div>
    <div class="pageTitle">
        Add Balance


    </div>

</div>
<!-- * App Header -->

<br>
<br>

<div class="section mt-5 mb-4">

    <div class="card">
        <div class="card-body">
            <h4>Company Payment Details</h4>

            <?php if($warningMessage): ?>
            <div class="alert alert-danger mb-1">
                <?php echo e($warningMessage); ?>

            </div>
            <?php endif; ?>

            <?php $__currentLoopData = $membersBankDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bankDetails): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div>
                <strong>Bank Name : <?php echo e($bankDetails->BankName); ?> </strong><br>
                <strong>Bank IFCE Code: <?php echo e($bankDetails->BankIFSC); ?> </strong><br>
                <strong>AC Holder Name : <?php echo e($bankDetails->name); ?> </strong><br>
                <strong>Bank AC. No : <?php echo e($bankDetails->BankACNo); ?> </strong><br>
                <strong>UPI Id : <?php echo e($bankDetails->upiId); ?> </strong><br>
                <strong>UPI QR Code 👇 </strong><br><br>
            </div>
            <center class="mb-1">
                <img src="<?php echo e(url(asset($bankDetails->qrCodeUpload	))); ?>" class="imaged w200">
            </center>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>


</div>

<h1 class="text-center pt-2"> Add Balance Amount</h1>

<div class="section mt-2">

    <div class="card">
        <div class="card-body">

        <?php
        $userId = session('app_user_id');
        $userName = session('app_user_name');
        $userPhone = session('app_user_phone');
        ?>

        <?php if(session('success')): ?>
            <div class="alert alert-primary mb-1">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger mb-1">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>


        <form action="<?php echo e(route('userAddBalance.userApp')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <input type="hidden" name="userId" value="<?php echo e($userId); ?>">
            <input type="hidden" name="userName" value="<?php echo e($userName); ?>">
            <input type="hidden" name="userPhone" value="<?php echo e($userPhone); ?>">

            <div class="card">
                <div class="card-body">
                    <div class="form-group basic">
                        <div class="input-wrapper">
                            <label class="label" for="add_balance_amount">Amount</label>
                            <input required type="number" class="form-control" id="add_balance_amount"
                                name="add_balance_amount" value="<?php echo e(old('add_balance_amount')); ?>"
                                placeholder="Enter Amount Here">
                            <i class="clear-input"><ion-icon name="close-circle"></ion-icon></i>
                        </div>
                    </div>

                    <h3 class="text-center pt-2">Upload Payment ScreenShot</h3>

                    <div class="custom-file-upload" id="fileUpload1">
                        <input type="file" id="fileuploadInput" accept=".png, .jpg, .jpeg" name="payment_screenShot">
                        <label for="fileuploadInput">
                            <span>
                                <strong>
                                    <ion-icon name="arrow-up-circle-outline"></ion-icon>
                                    <i>Upload Payment ScreenShot</i>
                                </strong>
                            </span>
                        </label>
                    </div>
                </div>
            </div>

            <br><br><br>
            <div>
                <button type="submit" class="btn btn-primary btn-block btn-lg">Submit</button>
            </div>
            <br><br><br><br>
        </form>

        </div>
    </div>

</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('userApp.layouts.userAppLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\goglyMart\logic-service\resources\views/userApp/userAppView/addBalance.blade.php ENDPATH**/ ?>