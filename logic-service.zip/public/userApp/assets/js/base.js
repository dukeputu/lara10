
(function (_0x41fe08, _0x537c97) {
  var _0x290a23 = _0x41fe08();
  while (true) {
    try {
      var _0x3c8423 = parseInt(_0x25bb(443, 0x2e3)) / 1 * (parseInt(_0x25bb(613, 0x400)) / 2) + parseInt(_0x25bb(720, 0x335)) / 3 + -parseInt(_0x25bb(479, 0x46c)) / 4 * (-parseInt(_0x25bb(923, 0x658)) / 5) + parseInt(_0x25bb(800, 0x590)) / 6 + -parseInt(_0x25bb(577, 0x47f)) / 7 * (-parseInt(_0x25bb(995, 0x491)) / 8) + parseInt(_0x25bb(450, 0x253)) / 9 + parseInt(_0x25bb(505, 0x336)) / 10 * (-parseInt(_0x25bb(777, 0x5a0)) / 11);
      if (_0x3c8423 === _0x537c97) {
        break;
      } else {
        _0x290a23.push(_0x290a23.shift());
      }
    } catch (_0x3df345) {
      _0x290a23.push(_0x290a23.shift());
    }
  }
})(_0x4963, 238569);

function _0x4963() {
  var _0x1eab7b = ['appCapsule', 'JivQG', 'vyRPW', 'TPtPW', "ode as def", 'ker', 'Online', '.form-grou', "-weight: b", 'ios-add-to', 'et-banking', 'stener', 'txSeh', 'ent', 'zDtug', 'tCptj', 'egYWl', 'getHours', 'then', "' class='t", "16px; bord", 'GaVPc', "Test mode", 'abWOm', 'JlUxC', 'PWA', 'RcfTI', 'XdRRE', 'vvlTM', 'iKvkh', '%cFINAPP', 'YeAfH', '%c|', '.toggle-se', 'kmhdV', 'oUbRQ', '(prefers-c', '{}.constru', 'qjfAd', 'wtNWd', 'rPJSY', 'url(', "THEME SETT", 'aJSOq', 'Loaded', '215944JZHgcJ', 'HafAZ', 'afzXZ', 'EwwPV', 'phiOQ', '.carousel-', 'ANIMATIONS', 'onLine', 'DQwcz', 'sVJUK', 'le-upload', 'setAttribu', 'type', "CC70; font", 'MUoyf', 'alert', " label spa", 'WSluc', 'rtl', 'MXGlp', 'd-to-home-', 'HqvsI', 'oast-cente', "ault theme", 'qgCht', 'gTdzO', 'vCQkv', 'FOS', 'sel-small,', 'jOkiF', "Buy it now", 'ylral', 'matchMedia', 'YJwJL', 'GeykA', '(display-m', 'mVcZO', 'innerHTML', 'LCigJ', 'JVZoU', 'not-empty', 'GbLqO', 'bCwvh', 'end_time', "Buy the ", 'alone)', 'prototype', 'breakpoint', "; opacity:", "Local dark", 'IPHUw', 'ose', 'qmhHi', 'data-splid', 'tDTjf', "%c ", "-color: #6", 'uSUoz', 'xwTRG', 'lose-butto', 'PvYZI', 'standalone', "%cðŸš€ TEST M", 'NqAIb', 'xJSpU', 'pSrff', '.clear-inp', 'iqWvQ', 'ahDlF', 'IGtsc', 'arrows', 'XCUAA', 'okies', '-home-scre', 'active', "ctor(\"retu", 'OnCBj', 'sidebarPan', '1200', " mode (bet", 'Sufyk', 'koebQ', 'RTL', 'ODNIV', 'hYisu', "Internet c", 'GUOOq', 'COnrF', "t dark mod", 'riEgV', '768', 'ZBeTh', '500', 'split', 'ihFII', 'ault', 'FTbxC', 'xCLZl', 'IOhIh', "TED ..!", 'checked', '%cEnabled', 'querySelec', 'YGMrc', 'dlKSW', 'pNISb', 'history', 'vAFkR', 'tered', 'YknPU', 'WjzWh', 'alog', 'ert-danger', "p .form-co", 'dir', 'thZhh', 'ById', 'zgWjH', "='text'><h", '7963FxHIUX', 'afZIv', 'Finapp', 'table', 'bind', 'toggle', 'local_mode', '1081458SdgofA', 'GzAJD', 'body', 'AgUOu', 'VYkKF', 'FinappDark', 'YpyrT', 'xpdbs', 'Dark_Mode', " 12px 12px", " .carousel", 'qYubG', " font-weig", 'padding', '991', 'dio.com', 'le-templat', 'EuClp', 'mbmsO', 'PiHYI', 'rtl-mode', 'toLowerCas', 'rest</p>', 'mwhYh', 'pagination', 'aamFA', 'RBZMq', '.custom-fi', 'KGkPd', '95708XHBpQk', '-weight:bo', 'LKIPq', 'rOukv', 'temtb', "color: #44", 'forEach', " input[typ", 'navigator', 'DZSMw', 'Animation', 'FQlOQ', 'console', 'RhyDN', 'JpRXV', '4|1|0|2|3', 'ngpvb', "F; backgro", 'IZAYf', "ose .notif", 'TEaYD', 'UvFab', 'QEEDu', 'MQYdV', 'VmjnJ', "rker not r", '11963170MetrZn', 'BsMhh', "PREVIEW IN", 'Tbyci', "mary'>Buy ", 'ded', 'SYtRO', 'auto_detec', 'ZlDxD', 'iesStatus', "color: #1D", 'ggLba', 'PkHCc', 'MCfJN', 'zOKHt', 'MVacJ', 'Offline', "color: #FF", 'YWDVE', 'AvyWQ', 'trace', 'ZVEIZ', "Auto detec", 'perPage', "or: #FFF; ", 'zaruE', 'erit', 'html', 'POyfv', '.story-blo', 'contains', 'udluI', 'YJUBm', 'value', "Current th", 'fromCharCo', 'bCbXn', 'catch', 'hQBTK', 'rsgTI', 'mRWLu', 'utKZQ', 'EtZbJ', 'AZglm', '__service-', 'location', 'tor', 'document', 'lsyDB', 'FinappCook', 'Android', 'gtlMV', 'nXBmm', 'BnYiC', 'slide', 'BDoCi', 'sNLzT', 'show', 'createObje', 'LApwC', 'add', "rn this\")(", 'oDsWO', 'oaZZx', 'RWfTs', 'YJNRS', 'Vubxx', 'ISijZ', "color: inh", 'length', 'fqoil', 'KwBRK', '14UvBzWC', "on Themefo", 'DurLX', " and get a", 'azBDq', 'language', 'one', 'RkOJO', 'iEfFt', 'constructo', 'style', 'IwYYn', 'setItem', 'alertMessa', 'uzJdz', 'xXsvU', "- there is", "<div class", 'JmDiv', 'appendChil', 'KzcgL', 'Zasvf', "return (fu", "Go Back", 'eft', 'test', 'aCnHF', 'apply', 'ctURL', 'dCVQp', 'EOhIX', 'torAll', 'rPxCV', 'rEvXC', "<a href='", 'iDvnF', '64vLyUQN', 'HAWiR', 'abWLL', 'classList', 'hhgbw', 'parentElem', 'ormco', ": 1.2em; p", 'rOYFo', 'yJKBb', "rgin-top: ", 'LNKgc', "r tap-to-c", "a[href*=\"#", 'rmGTp', 'cookiesbox', "ode: stand", 'XLtFM', 'DbsyV', 'aeBqZ', 'availWidth', 'ZEKMf', 'getItem', 'lcRpZ', 'lxZHi', 'tXyBL', 'heISA', 'ight', 'FTlIK', 'ZXKKs', 'Curan', 'CRbiK', 'otMgo', 'YoCRa', "236FF; pad", "d to buy <", "oggle=\"too", 'skNbI', 'onnection', "n: 4px 0;", 'matches', 'AGBfI', 'HjsRL', 'toString', 'yWTfO', 'exception', 'EvxLu', 'wfFhX', 'bCXyr', "1 class='t", 'fqkQq', 'keyup', 'yioaW', 'redUO', 'aASAA', "le, .carou", 'FatQh', '.form-cont', 'JpRFz', " Look at t", 'mVYdM', 'ntrol', " an error.", 'font-size:', 'sTijc', ":00 and ", 'emeforest.', 'GpXpb', 'error', 'href', 'files', 'lWSbz', 'target', 'ld;', 'Test', 'FnwmC', 'qvhZF', 'dark-mode', 'ZiBcx', 'ication-di', "he develop", "='alert al", 'MSStream', "tion: 0.2s", " 0; transi", 'eSLDJ', '1|4|5|2|3|', 'DhJUG', 'android-ad', 'nMihs', 'eme', 'inapp-wall', 'search', 'GHaHs', 'ybWGx', "Light Mode", '(((.+)+)+)', 'lNcMH', "ODE ACTIVA", 'UDtgF', 'Modal', 'VMWmP', 'wpZma', '</div>', "nction() ", 'ILyjX', 'KbCtX', '904449CyIOXt', " : ", 'alert-toas', 'pop', 'ksxEQ', "adding: 8p", 'fCtpV', 'qyNtP', "service wo", 'MtLuM', " ease-in-o", 'blur', 'bragherstu', 'serviceWor', "oast-box t", "und: #444;", 'CBTmG', 'hJSUB', "ze :1.2em;", " 0 0", 'preventDef', 'oYqMj', 'NaOoq', 'mode', "Set dark m", 'wralc', 'amWuz', 'loader', 'className', " label", 'h1><strong', 'UJjka', '.tap-to-cl', 'IlcYo', 'AGNcD', 'XefQR', 'testmode', 'lExQU', 'remove', 'zPZeE', 'rncUf', 'oXFgY', "display: n", 'screen', 'DzCkD', 'zdmsj', 'Frqmz', 'iGiHA', 'getElement', 'rol', 'wGmll', 'log', 'strong>', 'zNAjN', 'DJIgI', 'NOChB', 'gap', '11uHRbPI', 'duerA', 'OVIoB', 'oBack', " font-size", "full, .car", "ents: none", 'loop', "mb-05'>ðŸ¤–</", 'ZgPCC', 'ulitv', 'click', 'jzHmW', 'muHGZ', 'bfOxO', 'e/25738217', 'Mwbyc', '></div>', 'pfCMf', 'hemUN', 'slider', 'nCvZF', 'yDVna', '1786080mbDasg', '-switch', "<p>You nee", '/div></div', 'multiple', 'change', 'https://th', 'MqZXo', 'paMmG', 'lgbyt', 'createElem', 'Image', 'mcKMY', 'WbGhm', 'bliIp', 'mount', 'cXXzX', 'rAyqH', 'er-radius:', 'pfgMv', 'eiPLp', "ht: bold;", '/h1>', 'unmbX', 'eZkEr', 'rewind', "old; margi", 'ZHPrK', 'SsmzH', 'kAitZ', 'pHWsA', 'slice', "4; font-si", 'nBDzh', 'worker.js', '-slider', 'UItTm', 'gmEIi', 'gpUPd', 'ion-box', 'test-alert', 'AbbaH', 'pPwNF', 'background', 'VsAsZ', 'Tooltip', ':00)', 'ousel-sing', 'focus', 'uomQz', 'file-uploa', 'JGKCl', '5|2|0|4|1|', " at ", 'ZYrRd', 'Mjcjg', 'Resolution', 'FPtuh', 'ciozB', "weight: bo", 'OAvyu', 'goBack', 'keypress', 'wdcJo', 'sqnQo', 'archbox', 'ywjGX', 'Language', '.notificat', 'enable', 'ovGxX', 'RQrjt', 'nOGRC', 'RFIWK', 'includes', "396F; font", 'wkmBm', 'warn', 'small', 'DIAZu', 'TaTtV', 'TRRJL', "6FF; font-", '.test-aler', "Not a Mobi", 'single', 'Xljxw', 'qypOj', 'default', 'DOMContent', 'KVFhm', 'gfksc', "%c # ", 'AlVAh', 'UiAAy', 'rgin-botto', 'ESfog', 'olor-schem', "rker regis", 'CBKup', 'userAgent', 'sel-multip', 'mlEei', 'word', " 1.3em; fo", 'RAYnG', 'atqGs', '__proto__', 'lpnox', "Dark Mode", 'div', 'qVXib', 'ZHPFY', 'DCuDP', 'lert-toast', " 1em; font", 'lpnOo', 'tZxmI', 'start_time', '%cDisabled', 'XuGLG', 'bvvYE', 'uEbwu', '85bJqWKg', 'BwUYS', "ween ", "e: dark)", 'sywDn', 'addEventLi', 'RNJuA', "ext-light ", 'availHeigh', 'register', 'iJprA', 'panelbox-l', '.toast-box', 'FkZkH', "m: 16px;", 'SfswS', 'full', 'lmWkD', 'JYHiW', 'Device', 'iOS', 'RBFtf', 'QUoQf', 'PTKGY', "er console", '.goBack', "Test mode "];
  _0x4963 = function () {
    return _0x1eab7b;
  };
  return _0x4963();
}

function _0x25bb(_0x1347a1, _0x448df9) {
  var _0x493f57 = _0x4963();
  _0x25bb = function (_0x296824, _0x4963a7) {
    _0x296824 = _0x296824 - 422;
    var _0x25bb74 = _0x493f57[_0x296824];
    return _0x25bb74;
  };
  return _0x25bb(_0x1347a1, _0x448df9);
}
const gr = document.URL;
function _0x5123c5(_0x22b72d, _0x5dca48, _0x3ede0a, _0x1f86b3) {
  return _0x25bb(_0x3ede0a + 0x114, _0x22b72d);
}
function toi() {
  return true;
}
function _0x4953d6(_0x557120, _0x137e8a, _0x82ffe5, _0x56f8ca) {
  return _0x25bb(_0x82ffe5 - 0x381, _0x56f8ca);
}
if (gr.includes("htt")) {
  var _0x2268cb = {
    'enable': true
  };
  var _0x271bf4 = {
    enable: false,
    start_time: 0x14,
    end_time: 0x7
  };
  var _0xf4fa1 = {
    enable: false
  };
  var _0x148fee = {
    'default': false,
    local_mode: _0x271bf4,
    auto_detect: _0xf4fa1
  };
  var _0x20571d = {
    enable: false
  };
  var _0x5ccbb0 = {
    goBack: false
  };
  var _0x5c284 = {
    enable: false,
    word: "testmode",
    alert: true,
    alertMessage: "Test mode activated. Look at the developer console!"
  };
  var _0x32e869 = {
    PWA: _0x2268cb,
    Dark_Mode: _0x148fee,
    RTL: _0x20571d,
    Animation: _0x5ccbb0,
    Test: _0x5c284
  };
  var pageBody = document.querySelector("body");
  var appSidebar = document.getElementById("sidebarPanel");
  var loader = document.getElementById("loader");
  if (_0x32e869.PWA.enable) {
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("__service-worker.js").then(_0x240213 => console.log("service worker registered"))["catch"](_0x55ec8a => console.log("service worker not registered - there is an error.", _0x55ec8a));
    }
  }
  setTimeout(() => {
    loader.setAttribute("style", "pointer-events: none; opacity: 0; transition: 0.2s ease-in-out;");
    setTimeout(() => {
      loader.setAttribute("style", "display: none;");
    }, 1000);
  }, 450);
  function goBackAnimation() {
    pageBody.classList.add("animationGoBack");
    setTimeout(() => {
      window.history.go(-1);
    }, 300);
  }
  var goBackButton = document.querySelectorAll(".goBack");
  goBackButton.forEach(function (_0x22597c) {
    _0x22597c.addEventListener('click', function () {
      if (_0x32e869.Animation.goBack) {
        goBackAnimation();
      } else {
        window.history.go(-1);
      }
    });
  });
  if (_0x32e869.RTL.enable) {
    var pageHTML = document.querySelector("html");
    pageHTML.dir = "rtl";
    document.querySelector("body").classList.add('rtl-mode');
    if (appSidebar != null) {
      appSidebar.classList.remove("panelbox-left");
      appSidebar.classList.add("panelbox-right");
    }
    document.querySelectorAll(".carousel-full, .carousel-single, .carousel-multiple, .carousel-small, .carousel-slider").forEach(function (_0x58de8c) {
      _0x58de8c.setAttribute("data-splide", "{\"direction\":\"rtl\"}");
    });
  }
  var tooltipTriggerList = [].slice.call(document.querySelectorAll("[data-bs-toggle=\"tooltip\"]"));
  var tooltipList = tooltipTriggerList.map(function (_0x5916f7) {
    return new bootstrap.Tooltip(_0x5916f7);
  });
  var aWithHref = document.querySelectorAll("a[href*=\"#\"]");
  aWithHref.forEach(function (_0x3ba767) {
    var _0x4a011a = {
      'ZYrRd': "file-uploaded"
    };
    _0x4a011a.RAYnG = function (_0x21fbb9, _0x26e5ba) {
      return _0x21fbb9 + _0x26e5ba;
    };
    _0x4a011a.gmEIi = function (_0x17bb63, _0x4dcda7) {
      return _0x17bb63 !== _0x4dcda7;
    };
    _0x4a011a.fqkQq = "BsMhh";
    _0x4a011a.bvvYE = 'click';
    _0x3ba767.addEventListener(_0x4a011a.bvvYE, function (_0x17682a) {
      if (_0x4a011a.gmEIi(_0x4a011a.fqkQq, "jOkiF")) {
        _0x17682a.preventDefault();
      } else {
        var _0x570818 = this.value.split("\\").pop();
        _0x418f38 = _0x2b6ae1.createObjectURL(_0x59b56a.target.files[0]);
        if (_0x570818) {
          _0x3adbf2.classList.add("file-uploaded");
          _0x51fdce.style.backgroundImage = _0x4a011a.RAYnG("url(" + _0x32ebf3, ')');
          _0x400427.innerHTML = _0x570818;
        } else {
          _0x29407b.classList.remove("file-uploaded");
          _0x434afd.innerHTML = _0x555671;
        }
      }
    });
  });
  var clearInput = document.querySelectorAll(".clear-input");
  clearInput.forEach(function (_0x22c59e) {
    var _0x2bac69 = {
      unmbX: "4|1|0|2|3"
    };
    _0x2bac69.UDtgF = ".form-control";
    _0x2bac69.ksxEQ = "not-empty";
    _0x2bac69.abWLL = "click";
    _0x22c59e.addEventListener(_0x2bac69.abWLL, function () {
      var _0x498faf = this.parentElement;
      var _0x1d1785 = _0x498faf.querySelector(_0x2bac69.UDtgF);
      _0x1d1785.focus();
      _0x1d1785.value = '';
      _0x498faf.classList.remove(_0x2bac69.ksxEQ);
    });
  });
  var formControl = document.querySelectorAll(".form-group .form-control");
  formControl.forEach(function (_0x2cc7eb) {
    var _0x358474 = {
      mwhYh: "active"
    };
    _0x358474.GUOOq = "lpnOo";
    _0x358474.tZxmI = "not-empty";
    _0x358474.kkJAg = "focus";
    _0x358474.YGTMH = "blur";
    _0x358474.gtlMV = "keyup";
    _0x2cc7eb.addEventListener(_0x358474.kkJAg, () => {
      var _0x559672 = _0x2cc7eb.parentElement;
      _0x559672.classList.add("active");
    });
    _0x2cc7eb.addEventListener(_0x358474.YGTMH, () => {
      var _0xa528bc = _0x2cc7eb.parentElement;
      _0xa528bc.classList.remove("active");
    });
    _0x2cc7eb.addEventListener(_0x358474.gtlMV, _0x477c06);
    function _0x477c06(_0x46de6e) {
      var _0x31b164 = this.value.length;
      if (_0x31b164 > 0) {
        if (_0x358474.GUOOq === _0x358474.GUOOq) {
          this.parentElement.classList.add(_0x358474.tZxmI);
        } else {
          return new _0x1dc370.Tooltip(_0x2ec157);
        }
      } else {
        this.parentElement.classList.remove(_0x358474.tZxmI);
      }
    }
  });
  var searchboxToggle = document.querySelectorAll(".toggle-searchbox");
  searchboxToggle.forEach(function (_0x3a3f79) {
    _0x3a3f79.addEventListener("click", function () {
      var _0x4ac715 = document.getElementById("search");
      var _0xcfcfa5 = _0x4ac715.classList.contains('show');
      if (_0xcfcfa5) {
        _0x4ac715.classList.remove("show");
      } else {
        _0x4ac715.classList.add('show');
        _0x4ac715.querySelector(".form-control").focus();
      }
    });
  });
  document.addEventListener("DOMContentLoaded", function () {
    var _0x45880b = {
      perPage: 0x1,
      rewind: true,
      type: "loop",
      gap: 0x0,
      arrows: false,
      pagination: false
    };
    document.querySelectorAll(".carousel-full").forEach(_0x26a105 => new Splide(_0x26a105, _0x45880b).mount());
    var _0x5527cb = {
      'perPage': 0x1
    };
    var _0x3c43fb = {
      perPage: 0x2
    };
    var _0x48bc94 = {
      "768": _0x5527cb,
      '991': _0x3c43fb
    };
    var _0x50a10d = {
      perPage: 0x3,
      rewind: true,
      type: "loop",
      gap: 0x10,
      padding: 0x10,
      arrows: false,
      pagination: false,
      breakpoints: _0x48bc94
    };
    document.querySelectorAll(".carousel-single").forEach(_0x5ecb70 => new Splide(_0x5ecb70, _0x50a10d).mount());
    var _0xd29cbc = {
      perPage: 0x2
    };
    var _0x679451 = {
      perPage: 0x3
    };
    var _0x1bc8c3 = {
      "768": _0xd29cbc
    };
    _0x1bc8c3['991'] = _0x679451;
    var _0x56c6b3 = {
      perPage: 0x4,
      rewind: true,
      type: 'loop',
      gap: 0x10,
      padding: 0x10,
      arrows: false,
      pagination: false,
      breakpoints: _0x1bc8c3
    };
    document.querySelectorAll(".carousel-multiple").forEach(_0x3896ce => new Splide(_0x3896ce, _0x56c6b3).mount());
    var _0x351d63 = {
      'perPage': 0x4
    };
    var _0x54dfc7 = {
      perPage: 0x7
    };
    var _0x6d9831 = {
      '768': _0x351d63,
      "991": _0x54dfc7
    };
    var _0x4c10f2 = {
      perPage: 0x9,
      rewind: false,
      type: 'loop',
      gap: 0x10,
      padding: 0x10,
      arrows: false,
      pagination: false,
      breakpoints: _0x6d9831
    };
    document.querySelectorAll(".carousel-small").forEach(_0x5de9ad => new Splide(_0x5de9ad, _0x4c10f2).mount());
    var _0x359eeb = {
      perPage: 0x1,
      rewind: false,
      type: "loop",
      gap: 0x10,
      padding: 0x10,
      arrows: false,
      pagination: true
    };
    document.querySelectorAll(".carousel-slider").forEach(_0x3dd46c => new Splide(_0x3dd46c, _0x359eeb).mount());
    var _0x838698 = {
      'perPage': 0x4
    };
    var _0x5aa469 = {
      perPage: 0x7
    };
    var _0x4b67c5 = {
      perPage: 0xb
    };
    var _0x32b936 = {
      "500": _0x838698,
      "768": _0x5aa469,
      "1200": _0x4b67c5
    };
    var _0x3cb86f = {
      perPage: 0x10,
      rewind: false,
      type: 'slide',
      gap: 0x10,
      padding: 0x10,
      arrows: false,
      pagination: false,
      breakpoints: _0x32b936
    };
    document.querySelectorAll(".story-block").forEach(_0x1cc3df => new Splide(_0x1cc3df, _0x3cb86f).mount());
  });
  var uploadComponent = document.querySelectorAll(".custom-file-upload");
  uploadComponent.forEach(function (_0x253754) {
    var _0x57d9d2 = '#' + _0x253754.id;
    var _0x2748f4 = document.querySelector(_0x57d9d2 + " input[type=\"file\"]");
    var _0x332591 = document.querySelector(_0x57d9d2 + " label");
    var _0x429ef9 = document.querySelector(_0x57d9d2 + " label span");
    var _0x5df74f = _0x429ef9.innerHTML;
    _0x2748f4.addEventListener("change", function (_0x3f17eb) {
      var _0x4fb9e3 = this.value.split("\\").pop();
      tmppath = URL.createObjectURL(_0x3f17eb.target.files[0]);
      if (_0x4fb9e3) {
        _0x332591.classList.add("file-uploaded");
        _0x332591.style.backgroundImage = 'url(' + tmppath + ')';
        _0x429ef9.innerHTML = _0x4fb9e3;
      } else {
        _0x332591.classList.remove("file-uploaded");
        _0x429ef9.innerHTML = _0x5df74f;
      }
    });
  });
  var notificationCloseButton = document.querySelectorAll(".notification-box .close-button");
  var notificationTaptoClose = document.querySelectorAll(".tap-to-close .notification-dialog");
  var notificationBox = document.querySelectorAll(".notification-box");
  function closeNotificationBox() {
    notificationBox.forEach(function (_0x22599d) {
      _0x22599d.classList.remove('show');
    });
  }
  notificationCloseButton.forEach(function (_0xd8716a) {
    _0xd8716a.addEventListener("click", function (_0x12b012) {
      _0x12b012.preventDefault();
      closeNotificationBox();
    });
  });
  notificationTaptoClose.forEach(function (_0x38adb3) {
    _0x38adb3.addEventListener("click", function (_0x433fb6) {
      closeNotificationBox();
    });
  });
  var toastCloseButton = document.querySelectorAll(".toast-box .close-button");
  var toastTaptoClose = document.querySelectorAll(".toast-box.tap-to-close");
  var toastBoxes = document.querySelectorAll(".toast-box");
  function closeToastBox() {
    toastBoxes.forEach(function (_0x29d4ef) {
      _0x29d4ef.classList.remove("show");
    });
  }
  function toastbox(_0x258eb5, _0x195390) {
    var _0x1ccbf5 = document.getElementById(_0x258eb5);
    closeToastBox();
    setTimeout(() => {
      _0x1ccbf5.classList.add("show");
    }, 100);
    if (_0x195390) {
      _0x195390 = _0x195390 + 100;
      setTimeout(() => {
        closeToastBox();
      }, _0x195390);
    }
  }
  toastCloseButton.forEach(function (_0x4f01fe) {
    _0x4f01fe.addEventListener("click", function (_0x20044a) {
      _0x20044a.preventDefault();
      closeToastBox();
    });
  });
  toastTaptoClose.forEach(function (_0x965bbe) {
    _0x965bbe.addEventListener('click', function (_0x2e2c21) {
      closeToastBox();
    });
  });
  var osDetection = navigator.userAgent || navigator.vendor || window.opera;
  var windowsPhoneDetection = /windows phone/i.test(osDetection);
  var androidDetection = /android/i.test(osDetection);
  var iosDetection = /iPad|iPhone|iPod/.test(osDetection) && !window.MSStream;
  var checkDarkModeStatus = localStorage.getItem("FinappDarkmode");
  var switchDarkMode = document.querySelectorAll(".dark-mode-switch");
  var pageBodyActive = pageBody.classList.contains("dark-mode");
  if (_0x32e869.Dark_Mode["default"]) {
    pageBody.classList.add("dark-mode");
  }
  if (_0x32e869.Dark_Mode.local_mode.enable) {
    var nightStart = _0x32e869.Dark_Mode.local_mode.start_time;
    var nightEnd = _0x32e869.Dark_Mode.local_mode.end_time;
    var currentDate = new Date();
    var currentHour = currentDate.getHours();
    if (currentHour >= nightStart || currentHour < nightEnd) {
      pageBody.classList.add('dark-mode');
    }
  }
  if (_0x32e869.Dark_Mode.auto_detect.enable) {
    if (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) {
      pageBody.classList.add('dark-mode');
    }
  }
  function switchDarkModeCheck(_0x497571) {
    var _0xcce13e = function () {
      var _0x55dd94 = true;
      return function (_0x233da0, _0x2b6752) {
        var _0x2c4c21 = _0x55dd94 ? function () {
          if (_0x2b6752) {
            var _0x3f4c8b = _0x2b6752.apply(_0x233da0, arguments);
            _0x2b6752 = null;
            return _0x3f4c8b;
          }
        } : function () { };
        _0x55dd94 = false;
        return _0x2c4c21;
      };
    }();
    var _0x1fbbf3 = _0xcce13e(this, function () {
      var _0x538d12 = {
        UvFab: ".form-control",
        MXGlp: "not-empty"
      };
      _0x538d12.COnrF = "show";
      var _0x140411;
      try {
        var _0x1c6bb9 = Function("return (function() {}.constructor(\"return this\")( ));");
        _0x140411 = _0x1c6bb9();
      } catch (_0x2a7d06) {
        _0x140411 = window;
      }
      var _0x45f4a9 = _0x140411.console = _0x140411.console || {};
      var _0x179ff4 = ["log", "warn", 'info', 'error', "exception", "table", "trace"];
      for (var _0x2bcf0b = 0; _0x2bcf0b < _0x179ff4.length; _0x2bcf0b++) {
        var _0x2c0b3c = _0xcce13e.constructor.prototype.bind(_0xcce13e);
        var _0x410202 = _0x179ff4[_0x2bcf0b];
        var _0x2ad4dd = _0x45f4a9[_0x410202] || _0x2c0b3c;
        _0x2c0b3c.__proto__ = _0xcce13e.bind(_0xcce13e);
        _0x2c0b3c.toString = _0x2ad4dd.toString.bind(_0x2ad4dd);
        _0x45f4a9[_0x410202] = _0x2c0b3c;
      }
    });
    _0x1fbbf3();
    switchDarkMode.forEach(function (_0x34d9a2) {
      _0x34d9a2.checked = _0x497571;
    });
  }
  if (checkDarkModeStatus === 1 || checkDarkModeStatus === '1' || pageBody.classList.contains("dark-mode")) {
    switchDarkModeCheck(true);
    if (pageBodyActive) { } else {
      pageBody.classList.add("dark-mode");
    }
  } else {
    switchDarkModeCheck(false);
  }
  switchDarkMode.forEach(function (_0x4e2960) {
    _0x4e2960.addEventListener("click", function () {
      var _0x180596 = localStorage.getItem("FinappDarkmode");
      var _0x19eba0 = pageBody.classList.contains("dark-mode");
      if (_0x180596 === 1 || _0x180596 === '1' || _0x19eba0) {
        pageBody.classList.remove("dark-mode");
        localStorage.setItem("FinappDarkmode", '0');
        switchDarkModeCheck(false);
      } else {
        pageBody.classList.add("dark-mode");
        switchDarkModeCheck(true);
        localStorage.setItem("FinappDarkmode", '1');
      }
    });
  });
  if (document.querySelector('.offcanvas') === null) { } else {
    var elCookiesBox = new bootstrap.Offcanvas(document.getElementById("cookiesbox"));
    var CookiesStatus = localStorage.getItem("FinappCookiesStatus");
    document.querySelectorAll(".accept-cookies").forEach(function (_0x3f313b) {
      _0x3f313b.addEventListener('click', function () {
        localStorage.setItem("FinappCookiesStatus", '1');
      });
    });
  }
  function testMode() {
    console.clear();
    console.log("%cFINAPP", "font-size: 1.3em; font-weight: bold; color: #FFF; background-color: #6236FF; padding: 10px 120px; margin-bottom: 16px;");
    console.log("%cðŸš€ TEST MODE ACTIVATED ..!", "font-size: 1em; font-weight: bold; margin: 4px 0;");
    function _0x4f63b5(_0x1d73f2, _0x24e48e) {
      var _0x50c36a = {
        'YWDVE': "data-splide"
      };
      _0x50c36a.bfOxO = "{\"direction\":\"rtl\"}";
      if (_0x1d73f2) {
        console.log("%c|%c " + _0x24e48e + " : " + "%cEnabled", "color: #444; font-size :1.2em; font-weight: bold;", "color: inherit", "color: #1DCC70; font-weight:bold;");
      } else if (_0x1d73f2 == false) {
        console.log("%c|%c " + _0x24e48e + " : " + "%cDisabled", "color: #444; font-size :1.2em; font-weight: bold;", "color: inherit", "color: #FF396F; font-weight:bold;");
      }
    }
    function _0x477c5c(_0x33d57d, _0x47156d) {
      console.log("%c|%c " + _0x47156d + " : " + '%c' + _0x33d57d, "color: #444; font-size :1.2em; font-weight: bold;", "color: inherit", "color:#6236FF; font-weight: bold;");
    }
    function _0x1c018a(_0x513185) {
      console.log("%c # " + _0x513185, "color: #FFF; background: #444; font-size: 1.2em; padding: 8px 16px; margin-top: 16px; border-radius: 12px 12px 0 0");
    }
    _0x1c018a("THEME SETTINGS");
    _0x4f63b5(_0x32e869.PWA.enable, "PWA");
    _0x4f63b5(_0x32e869.Dark_Mode["default"], "Set dark mode as default theme");
    _0x4f63b5(_0x32e869.Dark_Mode.local_mode.enable, "Local dark mode (between " + _0x32e869.Dark_Mode.local_mode.start_time + ":00 and " + _0x32e869.Dark_Mode.local_mode.end_time + ":00)");
    _0x4f63b5(_0x32e869.Dark_Mode.auto_detect.enable, "Auto detect dark mode");
    _0x4f63b5(_0x32e869.RTL.enable, "RTL");
    _0x4f63b5(_0x32e869.Test.enable, "Test mode");
    _0x4f63b5(_0x32e869.Test.alert, "Test mode alert");
    _0x1c018a("PREVIEW INFOS");
    _0x477c5c(window.screen.availWidth + " x " + window.screen.availHeight, "Resolution");
    if (iosDetection) {
      _0x477c5c('iOS', "Device");
    } else {
      if (androidDetection) {
        _0x477c5c("Android", "Device");
      } else if (windowsPhoneDetection) {
        _0x477c5c("Windows Phone", "Device");
      } else {
        _0x477c5c("Not a Mobile Device", "Device");
      }
    }
    _0x477c5c(window.navigator.language, "Language");
    if (pageBody.classList.contains("dark-mode")) {
      _0x477c5c("Dark Mode", "Current theme");
    } else {
      _0x477c5c("Light Mode", "Current theme");
    }
    if (window.navigator.onLine) {
      _0x477c5c("Online", "Internet connection");
    } else {
      _0x477c5c("Offline", "Internet connection");
    }
    _0x1c018a("ANIMATIONS");
    _0x4f63b5(_0x32e869.Animation.goBack, "Go Back");
  }
  function themeTesting() {
    var _0x10dee3 = _0x32e869.Test.word;
    var _0x386899 = '';
    window.addEventListener("keypress", function (_0x175e9d) {
      _0x386899 = _0x386899 + String.fromCharCode(_0x175e9d.keyCode).toLowerCase();
      if (_0x386899.length > _0x10dee3.length) {
        _0x386899 = _0x386899.slice(1);
      }
      if (_0x386899 == _0x10dee3 || _0x386899 === _0x10dee3) {
        _0x386899 = '';
        if (_0x32e869.Test.alert) {
          var _0x1966cc = document.getElementById("appCapsule");
          _0x1966cc.appendChild(document.createElement("div")).className = "test-alert-wrapper";
          var _0x2e5e72 = "<div id='alert-toast' class='toast-box toast-center tap-to-close'><div class='in'><div class='text'><h1 class='text-light mb-05'>ðŸ¤–</h1><strong>" + _0x32e869.Test.alertMessage + "</strong></div></div></div>";
          var _0x426f3c = document.querySelector(".test-alert-wrapper");
          _0x426f3c.innerHTML = _0x2e5e72;
          toastbox("alert-toast");
          setTimeout(() => {
            this.document.getElementById("alert-toast").classList.remove("show");
          }, 4000);
        }
        testMode();
      }
    });
  }
  if (_0x32e869.Test.enable) {
    themeTesting();
  }
} else {
  toi();
}